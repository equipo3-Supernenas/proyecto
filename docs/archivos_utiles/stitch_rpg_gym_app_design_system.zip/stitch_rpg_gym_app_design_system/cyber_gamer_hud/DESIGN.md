---
name: Cyber-Gamer HUD
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#b9ccb5'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#849581'
  outline-variant: '#3b4b3a'
  surface-tint: '#00e55b'
  primary: '#edffe8'
  on-primary: '#003911'
  primary-container: '#00ff66'
  on-primary-container: '#007128'
  inverse-primary: '#006e27'
  secondary: '#d7ffc5'
  on-secondary: '#053900'
  secondary-container: '#2ff801'
  on-secondary-container: '#0f6d00'
  tertiary: '#f0fcff'
  on-tertiary: '#00363d'
  tertiary-container: '#85edff'
  on-tertiary-container: '#006c79'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6bff83'
  primary-fixed-dim: '#00e55b'
  on-primary-fixed: '#002107'
  on-primary-fixed-variant: '#00531b'
  secondary-fixed: '#79ff5b'
  secondary-fixed-dim: '#2ae500'
  on-secondary-fixed: '#022100'
  on-secondary-fixed-variant: '#095300'
  tertiary-fixed: '#9cf0ff'
  tertiary-fixed-dim: '#00daf3'
  on-tertiary-fixed: '#001f24'
  on-tertiary-fixed-variant: '#004f58'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
  background-void: '#0B0B0B'
  surface-base: '#121212'
  surface-card: '#1E1E1E'
  surface-elevated: '#2A2A2A'
  border-subtle: '#333333'
  border-active: '#00FF66'
  text-primary: '#FFFFFF'
  text-muted: '#A0A0A0'
  text-disabled: '#5A5A5A'
  rank-s: '#FFD700'
  rank-a: '#00FF66'
  rank-b: '#00E5FF'
  rank-c: '#A0A0A0'
  danger-streak: '#FF3366'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Chivo
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Chivo
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Chivo
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-rpg-stat:
    fontFamily: Space Mono
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-badge:
    fontFamily: Space Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.1em
  label-caption:
    fontFamily: Chivo
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.25rem
  margin-mobile: 1rem
  margin-tablet: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a high-performance, dark-mode native interface engineered at the convergence of cyberpunk telemetry, MMORPG character progression, and athletic execution. Tailored for dedicated fitness practitioners, gym enthusiasts, and gamers who view personal physical development as an iterative leveling system, the interface channels the visual cues of high-tech heads-up displays (HUDs) and gritty sci-fi terminals.

The aesthetic blends **Cyberpunk Minimalist** with **Tactile High-Contrast HUD UI**:
- Surfaces stay grounded in pitch blacks and industrial charcoals to maximize visual stamina and OLED efficiency.
- Interactive telemetry is energized by concentrated electric neon green accents, signaling live readiness, mission status, and energetic feedback.
- Information architecture prioritizes micro-rewards, transparent progression metrics (XP, level tiers, stat points like STR, END, AGI), and tactile confirmation loops.
- Visual noise is strictly minimized: glowing bloom and chromatic effects are applied intentionally as functional state indicators—progress bars, active system toggles, and quest completion triggers—rather than ambient distractions.

## Colors

The palette operates in a native dark environment built on deep void blacks and layered charcoal surfaces, punctured by hyper-vibrant phosphorescent neon accents. 

### Palette Logic
- **Primary (`#00FF66`)**: The signature electric neon green. Reserved for critical interactive highlights, active quest borders, filled progress states, and primary CTAs. Emits an energetic pulse that signifies vitality, power, and completed milestones.
- **Secondary (`#39FF14`)**: A high-intensity radio-green used for peak highlights, active glow coronas, and critical HUD triggers.
- **Tertiary (`#00E5FF`)**: Cyan telemetry accent used for technical parameters, secondary stat gains (e.g., AGI, Mana, stamina regeneration), and distinct rank signifiers.
- **Neutral (`#121212`)**: The structural container foundation, layered over `#0B0B0B` void canvases to provide separation without relying on abrasive light backgrounds.

### Specialized Accents
- **Ranks**: `rank-s` (`#FFD700`) conveys mythic/legendary mastery; `rank-a` (`#00FF66`) aligns with primary player excellence; `rank-b` (`#00E5FF`) and `rank-c` (`#A0A0A0`) form the standard tier progression.
- **Feedback & Streaks**: `danger-streak` (`#FF3366`) highlights active burn streaks, high-intensity exertion warnings, or urgent quest expirations.

## Typography

The typography pairings merge geometric industrial impact with technical data precision:
- **Display & Headlines (`Space Grotesk`)**: Technical, angular, and authoritative. Imparts a futuristic HUD aesthetic to workout titles, rank tiers, screen headers, and quest milestones.
- **Body & Interface Text (`Chivo`)**: Highly legible, muscular, and crisp. Ensures immediate scannability during intense workouts, fast reps, or dynamic timer checks.
- **RPG Telemetry & Labels (`Space Mono`)**: Dedicated monospaced type for numeric values, stats (STR, END, AGI), experience totals (+150 XP), timer counters, and rank badges. Fixed-width metrics prevent layout shifts during animated numeric counters.

All RPG stats and badge labels must be transformed to uppercase with tracking expanded (`0.08em` to `0.1em`) to mimic sci-fi diagnostic interfaces.

## Layout & Spacing

The layout is built on an adaptable 4-column (mobile) and 8/12-column (tablet/desktop) fluid grid structured around a strict 4px/8px baseline rhythm.

### Device Adaptations
- **Mobile (< 600px)**: 4-column system with a `margin-mobile` of 16px (`1rem`) and `gutter-mobile` of 12px (`0.75rem`). Cards and quest modules stack vertically in single columns, with critical interactive targets meeting a minimum touch dimension of 48×48px.
- **Tablet / Large Handheld (600px - 1024px)**: 8-column layout with 24px margins. Enables 2-column quest rosters, side-by-side player stat meters, and persistent split workout tracking.
- **Canvas Restraint**: Single-column vertical scroll remains the standard workflow for routine execution to prevent workout interruption and maintain rapid thumbs-first interaction.

## Elevation & Depth

Visual hierarchy does not rely on soft, realistic physical dropshadows. Instead, elevation uses a combination of **Tonal Layering**, **Crisp Mechanical Outlines**, and **Cybernetic Neon Glows**.

### Elevation Tiers
1. **Tier 0 (Canvas Void)**: `#0B0B0B` base background. Zero elevation.
2. **Tier 1 (Surface Cards & Modules)**: `#1E1E1E` fill bordered by 1px solid `#333333`. Flat, technical separation from the void.
3. **Tier 2 (Elevated Overlays & Flyouts)**: `#2A2A2A` fill with 1px solid `#444444`. Used for dropdown stats, mod dials, and bottom navigation docking.
4. **Tier 3 (Active / Focused States)**: Surface fill `#1E1E1E` or `#2A2A2A` accented by a 1px or 1.5px solid `#00FF66` border paired with a diffused neon glow: `0px 0px 14px rgba(0, 255, 102, 0.35)`.

### The Glow System
Glows indicate functional readiness, completion, and power surges:
- **Interactive Button / CTA**: `box-shadow: 0px 0px 16px rgba(0, 255, 102, 0.45)`.
- **XP / Gauge Fill**: Inner glow `inset 0px 0px 8px rgba(57, 255, 20, 0.6)` and edge bleed `0px 0px 12px rgba(0, 255, 102, 0.5)`.
- **Passive Elements**: Non-interactive containers must strictly omit glow to avoid eye fatigue.

## Shapes

The interface embraces a low-radius, angular geometric language (`roundedness: 1`, base 4px radius) reinforcing military hardware and tech terminals.

- **Standard Containers & Cards**: Fixed at 4px (`rounded-sm`), preventing soft bubble contours in favor of industrial structure.
- **Chips, Stat Badges & Tags**: 4px radius or chamfered/beveled 45-degree edge clips on opposing corners (`clip-path`) for high-tier loot and rank badges.
- **Progress Bars**: 2px to 4px subtle rounded caps, housing razor-sharp segmented rect interior blocks.
- **CTAs**: 4px border-radius with crisp 1px structural framing.

## Components

### Buttons & Interactive CTAs
- **Primary CTA ("Iniciar Misión", "+ Crear Nueva Rutina")**:
  - Background: `#00FF66`.
  - Label: `#0B0B0B`, typography `label-rpg-stat`, uppercase, bold.
  - Border: 1px solid `#39FF14`.
  - Shadow: `0px 0px 16px rgba(0, 255, 102, 0.45)`.
  - State (Pressed): Background drops to `#00CC52`, shadow condenses to `0px 0px 8px rgba(0, 255, 102, 0.3)`.
- **Secondary Action Button**:
  - Background: `#1E1E1E`.
  - Label: `#FFFFFF`.
  - Border: 1px solid `#333333`.
  - State (Hover/Focus): Border illuminates to `#00FF66` with subtle text glow.

### XP & Stat Progress Bars
- **Track**: Height 8px to 14px, background `#121212`, border 1px solid `#2A2A2A`, corner radius 2px.
- **Fill**: Gradient from `#00FF66` to `#39FF14` with a drop shadow of `0px 0px 10px rgba(0, 255, 102, 0.6)`.
- **Segmented Stat Bars (STR, END, AGI)**: Split into 10 discrete modular blocks separated by 2px `#0B0B0B` gutters. Unfilled blocks rendered in `#222222`.

### Quest & Routine Cards
- **Container**: Background `#1E1E1E`, 1px border `#333333`, padding `space-md` (16px).
- **Completed State**: Border transitions to `#00FF66` with a low glow; title receives subtle line-through with muted text (`#A0A0A0`); XP badge pulses in `#00FF66`.
- **Reward Indicators**: Monospaced chip with dark `#0B0B0B` background, border `#00FF66` 1px, text `#00FF66` (+150 XP, +10 STR).

### Rank & Achievement Badges
- **Display**: Tier badges (S, A, B, C) encased in a hexagonal or 4px chamfered frame.
- **Palette**:
  - Rank S: Border and typography `#FFD700`, glow `rgba(255, 215, 0, 0.4)`.
  - Rank A: Border and typography `#00FF66`, glow `rgba(0, 255, 102, 0.4)`.
  - Rank B: Border and typography `#00E5FF`, glow `rgba(0, 229, 255, 0.3)`.
  - Rank C: Border and typography `#A0A0A0`, no glow.

### Bottom Navigation Bar
- **Dock**: Fixed bottom, height 64px, surface `#121212`, top border 1px solid `#2A2A2A`.
- **Items**: 5-column layout. Unselected items rendered in `#A0A0A0` with 20px icons.
- **Active State**: Icon and label glow in `#00FF66`, anchored by a 2px micro-indicator bar on the top edge of the tab.

### Inputs & Toggles
- **Input Fields**: Background `#121212`, border 1px solid `#333333`, text `#FFFFFF`, caret `#00FF66`. Focus state highlights border to `#00FF66` with zero outer displacement.
- **Quest Checkboxes**: Custom 20×20px square, 2px radius, unselected `#222222` border. Selected state fills with `#00FF66`, bearing a sharp black neon tick icon.